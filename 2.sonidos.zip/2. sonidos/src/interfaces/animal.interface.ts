

export interface Animal{
  nombre: string;
  imagen: string;
  audio: string;
  duracion: number;
  reproduciendo: boolean;
}
